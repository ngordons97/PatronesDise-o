package metodos;

public class Carro implements Vehiculo {
    @Override
    public void conducir() {
        System.out.println("Manejando un carro.");
    }
}
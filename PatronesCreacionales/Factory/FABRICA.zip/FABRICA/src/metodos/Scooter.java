package metodos;

public class Scooter implements Vehiculo {
	 @Override
	    public void conducir() {
	        System.out.println("Manejando un scooter.");
	    }
}

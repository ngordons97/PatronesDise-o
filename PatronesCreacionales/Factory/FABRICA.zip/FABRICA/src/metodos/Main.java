package metodos;

public class Main {
    public static void main(String[] args) {
    	
        Vehiculo carro = VehiculoFactory.crearVehiculo("carro");
        carro.conducir();  

        Vehiculo moto = VehiculoFactory.crearVehiculo("moto");
        moto.conducir();   
        
        Vehiculo scooter = VehiculoFactory.crearVehiculo("scooter");
        scooter.conducir();
    }
}

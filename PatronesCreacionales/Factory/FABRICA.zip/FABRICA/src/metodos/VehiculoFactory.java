package metodos;

public class VehiculoFactory {
    public static Vehiculo crearVehiculo(String tipo) {
        if (tipo.equalsIgnoreCase("carro")) {
            return new Carro();
        } else if (tipo.equalsIgnoreCase("moto")) {
            return new Moto();
        } else if (tipo.equalsIgnoreCase("scooter")) {
            return new Scooter();
        }
        throw new IllegalArgumentException("Tipo de vehículo desconocido.");
    }
}
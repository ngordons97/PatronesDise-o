package metodos;

public interface Vehiculo {
    void conducir();
    
}
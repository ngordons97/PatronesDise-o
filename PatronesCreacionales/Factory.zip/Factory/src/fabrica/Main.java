package fabrica;

public class Main {

	public static void main(String[] args) {
        NotificacionFactory factory;

        
        factory = new EmailNotificacionFactory();
        Notificacion emailNotificacion = factory.crearNotificacion();
        emailNotificacion.notificacionUser();

        
        factory = new SMSNotificacionFactory();
        Notificacion smsNotificacion = factory.crearNotificacion();
        smsNotificacion.notificacionUser();

        
        factory = new PushNotificacionFactory();
        Notificacion pushNotificacion = factory.crearNotificacion();
        pushNotificacion.notificacionUser();
    }
}

package fabrica;

public class EmailNotificacionFactory extends NotificacionFactory {
    @Override
    public Notificacion crearNotificacion() {
        return new EmailNotificacion();
    }}

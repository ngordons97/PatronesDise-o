package fabrica;

public class EmailNotificacion implements Notificacion {
    @Override
    public void notificacionUser() {
        System.out.println("Enviando una notificación por Email...");
    }
}

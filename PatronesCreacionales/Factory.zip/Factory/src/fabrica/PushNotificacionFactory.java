package fabrica;

public class PushNotificacionFactory  extends NotificacionFactory {
    @Override
    public Notificacion crearNotificacion() {
        return new PushNotificacion();
    }
}

package fabrica;

public class PushNotificacion implements Notificacion {
    @Override
    public void notificacionUser() {
        System.out.println("Enviando una notificación Push...");
    }
}

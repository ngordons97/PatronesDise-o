package fabrica;

public class SMSNotificacion implements Notificacion {
    @Override
    public void notificacionUser() {
        System.out.println("Enviando una notificación por SMS...");
    }
}

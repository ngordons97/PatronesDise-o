package fabrica;

public interface Notificacion {
    void notificacionUser();
}

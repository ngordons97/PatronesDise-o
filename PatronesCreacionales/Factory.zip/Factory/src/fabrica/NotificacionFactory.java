package fabrica;

public abstract class NotificacionFactory {
    public abstract Notificacion crearNotificacion();
}
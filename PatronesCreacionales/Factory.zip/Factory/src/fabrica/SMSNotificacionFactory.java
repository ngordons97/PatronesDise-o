package fabrica;

public class SMSNotificacionFactory extends NotificacionFactory {
    @Override
    public Notificacion crearNotificacion() {
        return new SMSNotificacion();
    }

}
